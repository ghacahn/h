﻿#pragma once
#include "afxdialogex.h"


// Диалоговое окно Dialog_7

class Dialog_7 : public CDialogEx
{
	DECLARE_DYNAMIC(Dialog_7)

public:
	Dialog_7(CWnd* pParent = nullptr);   // стандартный конструктор
	virtual ~Dialog_7();

// Данные диалогового окна
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG7 };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // поддержка DDX/DDV

	DECLARE_MESSAGE_MAP()
public:
	int payment_for_services;
	afx_msg void OnBnClickedOk2();
};
