﻿#pragma once
#include "afxdialogex.h"


// Диалоговое окно dialog_6

class dialog_6 : public CDialogEx
{
	DECLARE_DYNAMIC(dialog_6)

public:
	dialog_6(CWnd* pParent = nullptr);   // стандартный конструктор
	virtual ~dialog_6();

// Данные диалогового окна
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG6 };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // поддержка DDX/DDV

	DECLARE_MESSAGE_MAP()
public:
	int summ_enter_minus;
	afx_msg void OnBnClickedOk2();
};
