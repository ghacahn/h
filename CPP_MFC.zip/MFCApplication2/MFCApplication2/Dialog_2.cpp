﻿// Dialog_2.cpp: файл реализации
//

#include "pch.h"
#include "MFCApplication2.h"
#include "afxdialogex.h"
#include "Dialog_2.h"
#include "Money_summ.h"
#include "Dialog_1.h"
#include "MFCApplication2Dlg.h"
#include "Dialog_7.h"
//#include "Money_summ.h"


// Диалоговое окно Dialog_2

IMPLEMENT_DYNAMIC(Dialog_2, CDialogEx)

Dialog_2::Dialog_2(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_DIALOG2, pParent)
{

}

Dialog_2::~Dialog_2()
{
}

void Dialog_2::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(Dialog_2, CDialogEx)
	ON_BN_CLICKED(IDCANCEL, &Dialog_2::OnBnClickedCancel)
	ON_BN_CLICKED(IDOK, &Dialog_2::OnBnClickedOk)
	ON_BN_CLICKED(IDOK7, &Dialog_2::OnBnClickedOk7)
	ON_BN_CLICKED(IDOK5, &Dialog_2::OnBnClickedOk5)
	ON_BN_CLICKED(IDOK4, &Dialog_2::OnBnClickedOk4)
	ON_BN_CLICKED(IDOK2, &Dialog_2::OnBnClickedOk2)
	ON_BN_CLICKED(IDOK3, &Dialog_2::OnBnClickedOk3)
END_MESSAGE_MAP()


// Обработчики сообщений Dialog_2


void Dialog_2::OnBnClickedCancel()
{
	// TODO: добавьте свой код обработчика уведомлений
	CDialogEx::OnCancel();
}

void Dialog_2::OnBnClickedOk()
{
	this->EndDialog(IDOK);
	Dialog_7 dlg2;
	dlg2.DoModal();
}

void Dialog_2::OnBnClickedOk7()
{
	this->EndDialog(IDOK);
	Dialog_7 dlg2;
	dlg2.DoModal();
}

void Dialog_2::OnBnClickedOk5()
{
	this->EndDialog(IDOK);
	Dialog_7 dlg2;
	dlg2.DoModal();
}

void Dialog_2::OnBnClickedOk4()
{
	this->EndDialog(IDOK);
	Dialog_7 dlg2;
	dlg2.DoModal();
}

void Dialog_2::OnBnClickedOk2()
{
	this->EndDialog(IDOK);
	Dialog_7 dlg2;
	dlg2.DoModal();
}

void Dialog_2::OnBnClickedOk3()
{
	this->EndDialog(IDOK);
	// Создаем и отображаем второе окно
	CMFCApplication2Dlg dlg2;
	dlg2.DoModal();
}
