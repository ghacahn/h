﻿// admin_enter.cpp: файл реализации
//

#include "pch.h"
#include "MFCApplication2.h"
#include "afxdialogex.h"
#include "admin_enter.h"


// Диалоговое окно admin_enter

IMPLEMENT_DYNAMIC(admin_enter, CDialogEx)

admin_enter::admin_enter(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_DIALOG4, pParent)
{

}

admin_enter::~admin_enter()
{
}

void admin_enter::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(admin_enter, CDialogEx)
	ON_BN_CLICKED(IDOK, &admin_enter::OnBnClickedOk)
END_MESSAGE_MAP()


// Обработчики сообщений admin_enter


void admin_enter::OnBnClickedOk()
{
	// TODO: добавьте свой код обработчика уведомлений
	CDialogEx::OnOK();
}
