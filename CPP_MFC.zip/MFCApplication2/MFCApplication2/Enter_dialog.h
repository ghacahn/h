﻿#pragma once
#include "afxdialogex.h"


// Диалоговое окно Enter_dialog

class Enter_dialog : public CDialogEx
{
	DECLARE_DYNAMIC(Enter_dialog)

public:
	Enter_dialog(CWnd* pParent = nullptr);   // стандартный конструктор
	virtual ~Enter_dialog();

// Данные диалогового окна
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG3 };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // поддержка DDX/DDV

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedOk2();
};
