﻿// dialog_6.cpp: файл реализации
//

#include "pch.h"
#include "MFCApplication2.h"
#include "afxdialogex.h"
#include "dialog_6.h"
#include "change_balance.h"
#include "MFCApplication2Dlg.h"


// Диалоговое окно dialog_6

IMPLEMENT_DYNAMIC(dialog_6, CDialogEx)

dialog_6::dialog_6(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_DIALOG6, pParent)
	, summ_enter_minus(0)
{

}

dialog_6::~dialog_6()
{
}

void dialog_6::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT2, summ_enter_minus);
}


BEGIN_MESSAGE_MAP(dialog_6, CDialogEx)
	ON_BN_CLICKED(IDOK2, &dialog_6::OnBnClickedOk2)
END_MESSAGE_MAP()


// Обработчики сообщений dialog_6

void dialog_6::OnBnClickedOk2()
{
	UpdateData(TRUE);
	change_balance card1;
	card1.card_number = card_num.c_str();
	card1.withdraw_money(summ_enter_minus, 0);
	this->EndDialog(IDOK);
	CMFCApplication2Dlg dlg2;
	dlg2.DoModal();
}
