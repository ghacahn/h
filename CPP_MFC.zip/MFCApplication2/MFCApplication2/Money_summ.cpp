﻿// Money_summ.cpp: файл реализации
//

#include "pch.h"
#include "MFCApplication2.h"
#include "afxdialogex.h"
#include "Money_summ.h"
#include "client_enter.h"
#include "change_balance.h"
#include "MFCApplication2Dlg.h"


// Диалоговое окно Money_summ
string card_num;
IMPLEMENT_DYNAMIC(Money_summ, CDialogEx)

Money_summ::Money_summ(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_DIALOG5, pParent)
	, enter_summ_plus(0)
{

}

Money_summ::~Money_summ()
{
}

void Money_summ::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT2, enter_summ_plus);
}


BEGIN_MESSAGE_MAP(Money_summ, CDialogEx)
	ON_BN_CLICKED(IDOK, &Money_summ::OnBnClickedOk)
END_MESSAGE_MAP()


// Обработчики сообщений Money_summ

void Money_summ::OnBnClickedOk() // внести сумму
{
	UpdateData(TRUE);
	change_balance card1; 
	card1.card_number = card_num.c_str();
	card1.deposit_money(enter_summ_plus);
	string mess_str = "Баланс пополнен на " + to_string(enter_summ_plus) + " рублей";
	MessageBoxA(NULL, mess_str.c_str(), "Успешная операция", MB_ICONINFORMATION | MB_OK);
	this->EndDialog(IDOK);
	CMFCApplication2Dlg dlg2;
	dlg2.DoModal();
}
