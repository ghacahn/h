﻿#pragma once
#include "afxdialogex.h"


// Диалоговое окно admin_enter

class admin_enter : public CDialogEx
{
	DECLARE_DYNAMIC(admin_enter)

public:
	admin_enter(CWnd* pParent = nullptr);   // стандартный конструктор
	virtual ~admin_enter();

// Данные диалогового окна
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG4 };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // поддержка DDX/DDV

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedOk();
};
