﻿// Dialog_7.cpp: файл реализации
//

#include "pch.h"
#include "MFCApplication2.h"
#include "afxdialogex.h"
#include "Dialog_7.h"
#include "change_balance.h"
#include "MFCApplication2Dlg.h"


// Диалоговое окно Dialog_7

IMPLEMENT_DYNAMIC(Dialog_7, CDialogEx)

Dialog_7::Dialog_7(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_DIALOG7, pParent)
	, payment_for_services(0)
{

}

Dialog_7::~Dialog_7()
{
}

void Dialog_7::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT2, payment_for_services);
}


BEGIN_MESSAGE_MAP(Dialog_7, CDialogEx)
	ON_BN_CLICKED(IDOK2, &Dialog_7::OnBnClickedOk2)
END_MESSAGE_MAP()


// Обработчики сообщений Dialog_7

void Dialog_7::OnBnClickedOk2()
{
	UpdateData(TRUE);
	change_balance card1;
	card1.card_number = card_num.c_str();
	card1.withdraw_money(payment_for_services, 1);
	this->EndDialog(IDOK);
	CMFCApplication2Dlg dlg2;
	dlg2.DoModal();
}
