﻿#pragma once
#include "afxdialogex.h"


// Диалоговое окно Money_summ

class Money_summ : public CDialogEx
{
	DECLARE_DYNAMIC(Money_summ)

public:
	Money_summ(CWnd* pParent = nullptr);   // стандартный конструктор
	virtual ~Money_summ();

// Данные диалогового окна
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG5 };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // поддержка DDX/DDV

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedOk();
	int enter_summ_plus;
};
