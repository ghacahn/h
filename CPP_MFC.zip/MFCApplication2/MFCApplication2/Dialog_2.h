﻿#pragma once
#include "afxdialogex.h"


// Диалоговое окно Dialog_2

class Dialog_2 : public CDialogEx
{
	DECLARE_DYNAMIC(Dialog_2)

public:
	Dialog_2(CWnd* pParent = nullptr);   // стандартный конструктор
	virtual ~Dialog_2();

// Данные диалогового окна
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG2 };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // поддержка DDX/DDV

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedCancel();
	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedOk7();
	afx_msg void OnBnClickedOk5();
	afx_msg void OnBnClickedOk4();
	afx_msg void OnBnClickedOk2();
	afx_msg void OnBnClickedOk3();
};
