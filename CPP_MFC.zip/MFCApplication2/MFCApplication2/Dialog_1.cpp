﻿// Dialog_1.cpp: файл реализации
//

#include "pch.h"
#include "MFCApplication2.h"
#include "afxdialogex.h"
#include "Dialog_1.h"
#include "MFCApplication2Dlg.h"
#include "client_enter.h"
#include <windows.h>
#include <iostream>
#include <string>

// Диалоговое окно Dialog_1
extern std::string card_num;
IMPLEMENT_DYNAMIC(Dialog_1, CDialogEx)

Dialog_1::Dialog_1(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_DIALOG1, pParent)
	, m_edit_1(0)
	, m_edit_2(0)
	, m_edit1(0)
	, m_edit2(0)
	, enter_1(_T(""))
	, enter_2(_T(""))
{

}

Dialog_1::~Dialog_1()
{
}

void Dialog_1::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT3, enter_1);
	DDX_Text(pDX, IDC_EDIT4, enter_2);
}


BEGIN_MESSAGE_MAP(Dialog_1, CDialogEx)
	ON_BN_CLICKED(IDOK, &Dialog_1::OnBnClickedOk)
	//ON_EN_CHANGE(IDC_EDIT2, &Dialog_1::OnEnChangeEdit2)
	//ON_BN_CLICKED(IDC_BUTTON1, &Dialog_1::OnBnClickedButton1)
	ON_EN_CHANGE(IDC_EDIT3, &Dialog_1::OnEnChangeEdit3)
	ON_EN_CHANGE(IDC_EDIT4, &Dialog_1::OnEnChangeEdit4)
END_MESSAGE_MAP()


// Обработчики сообщений Dialog_1


void Dialog_1::OnBnClickedOk()
{
	UpdateData(TRUE);
	client_enter check_enter1;
	check_enter1.card_number = enter_1;
	check_enter1.password = enter_2;
	int f = check_enter1.check_card();
	string q = to_string(f);
	if (f == 1)
	{
		// Закрываем текущее окно
		this->EndDialog(IDOK);
		// Создаем и отображаем второе окно
		CMFCApplication2Dlg dlg2;
		dlg2.DoModal();
	}
	else
	{
		MessageBoxA(NULL, "Ошибка в вводе номера карты или пароля!", "Ошибка", MB_ICONERROR | MB_OK);
	}

}


void Dialog_1::OnEnChangeEdit2()
{
	// TODO:  Если это элемент управления RICHEDIT, то элемент управления не будет
	// send this notification unless you override the CDialogEx::OnInitDialog()
	// функция и вызов CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.

	// TODO:  Добавьте код элемента управления
}


void Dialog_1::OnBnClickedButton1()
{
	// TODO: добавьте свой код обработчика уведомлений
}

void Dialog_1::OnEnChangeEdit3()
{
	// TODO:  Если это элемент управления RICHEDIT, то элемент управления не будет
	// send this notification unless you override the CDialogEx::OnInitDialog()
	// функция и вызов CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.

	// TODO:  Добавьте код элемента управления
}

void Dialog_1::OnEnChangeEdit4()
{
	// TODO:  Если это элемент управления RICHEDIT, то элемент управления не будет
	// send this notification unless you override the CDialogEx::OnInitDialog()
	// функция и вызов CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.

	// TODO:  Добавьте код элемента управления
}
