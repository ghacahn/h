﻿#pragma once
#include "afxdialogex.h"


// Диалоговое окно Dialog_1

class Dialog_1 : public CDialogEx
{
	DECLARE_DYNAMIC(Dialog_1)

public:
	Dialog_1(CWnd* pParent = nullptr);   // стандартный конструктор
	virtual ~Dialog_1();

// Данные диалогового окна
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG1 };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // поддержка DDX/DDV

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedOk();
	afx_msg void OnEnChangeEdit2();
	int m_edit_1;
	int m_edit_2;
	int m_edit1;
	int m_edit2;
	CString enter_1;
	CString enter_2;
	afx_msg void OnBnClickedButton1();
	afx_msg void OnEnChangeEdit3();
	afx_msg void OnEnChangeEdit4();
};
