#pragma once
#include <iostream>
#include <fstream>
#include <windows.h>
#include <string>
#include <tchar.h>
#include <atlstr.h>

using namespace std;
extern string card_num;
class client_enter
{
public:
	CString card_number;
	CString password;
    int card_balance;
    inline int check_card();

};

inline int client_enter::check_card()
{
    ifstream file("clients.txt"); 
    string line;
    string password_enter;
    string card_number_enter;
    while (getline(file, line)) 
    { 
        card_number_enter = line.substr(0, 16);
        password_enter = line.substr(17, 4);
        if (password == password_enter.c_str() && card_number == card_number_enter.c_str()) {
            card_num = card_number_enter;
            return 1;
        }
    }
    file.close();
	return 0;
}

