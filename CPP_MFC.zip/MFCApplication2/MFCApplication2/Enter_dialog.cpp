﻿// Enter_dialog.cpp: файл реализации
//

#include "pch.h"
#include "MFCApplication2.h"
#include "afxdialogex.h"
#include "Enter_dialog.h"
#include "Dialog_1.h"
#include "admin_enter.h"


// Диалоговое окно Enter_dialog

IMPLEMENT_DYNAMIC(Enter_dialog, CDialogEx)

Enter_dialog::Enter_dialog(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_DIALOG3, pParent)
{

}

Enter_dialog::~Enter_dialog()
{
}

void Enter_dialog::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(Enter_dialog, CDialogEx)
	ON_BN_CLICKED(IDOK, &Enter_dialog::OnBnClickedOk)
	ON_BN_CLICKED(IDOK2, &Enter_dialog::OnBnClickedOk2)
END_MESSAGE_MAP()


// Обработчики сообщений Enter_dialog


void Enter_dialog::OnBnClickedOk()
{
	this->EndDialog(IDOK);
	Dialog_1 dlg2;
	dlg2.DoModal();
}

void Enter_dialog::OnBnClickedOk2()
{
	this->EndDialog(IDOK);
	admin_enter dlg2;
	dlg2.DoModal();
}
